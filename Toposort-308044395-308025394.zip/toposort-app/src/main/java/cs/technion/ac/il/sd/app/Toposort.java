package cs.technion.ac.il.sd.app;

import java.io.File;

public interface Toposort {
  void processFile(File file);
}
