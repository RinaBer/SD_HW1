package graph;

import javafx.util.Pair;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Created by rina.berlin on 4/11/2016.
 */

public class Graph {
    private HashSet<Node> vertexes;

    public Graph(HashSet<Integer> vertexes, HashSet<Pair<Integer, Integer> > edges){
        this.vertexes = new HashSet<Node>();
        for (Integer v : vertexes) {
            addVertex(v);
        }
        for (Pair p : edges) {
            try {
                addEdge(p);
            } catch (Exception e){
                continue;
            }
        }
    }
    private void addVertex(Integer v){
        Node node = new Node(v);
        vertexes.add(node);
        if (v == 183) {
            Optional<Node> s = vertexes.stream().filter(node1 -> node1.getVertexID() > 182).findFirst();//==edge.getKey());
            s.get();
        }
    }
    private void addEdge(Pair<Integer, Integer> edge) throws Exception{
        Stream s = vertexes.stream().filter(node->node.getVertexID()>180);//==edge.getKey());
        Iterator<Node> itr = s.iterator();
        if (!(itr.hasNext())) {
            Optional<Node> source = s.findFirst();
        }
        Optional<Node> target = vertexes.stream().filter(node->node.getVertexID()==edge.getValue()).findFirst();
        try {
        //    source.get().addNeighbor(edge.getValue());
            target.get().incDegree();
        } catch (NullPointerException e){
            throw new Exception("node wasn't found in add edge");
        }
    }

    public void removeVertex(Node node){
        List<Integer> list = node.getNeighbors();
        vertexes = vertexes.stream().map(v-> {if(list.contains(v.getVertexID())) v.decDegree(); return v;}).
                collect(Collectors.toCollection(HashSet<Node>::new));
        vertexes.remove(node);
    }

    public Optional<Node> getSource(){
        Optional<Node> s = vertexes.stream().filter(node->!node.hasEnteringEdages()).findFirst();
        return s;
    }

    public Boolean isEmpty(){
        return vertexes.isEmpty();
    }
}
