package graph;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by rina.berlin on 4/11/2016.
 */
public class Node {
    private Integer v;
    private List<Integer> neighbors;
    private Integer inDegree;

    public Node(Integer v){
        this.v = v;
        neighbors = new LinkedList<>();
        this.inDegree = 0;
    }

    @Override
    public boolean equals(Object n){
        if (this == n){
            return true;
        }
        if (!(n instanceof Node)) {
            return false;
        }
        Node other = (Node)n;
        return this.v == other.v;
    }

    public Integer getVertexID(){
        return this.v;
    }

    void incDegree(){
        this.inDegree++;
    }

    void decDegree(){
        this.inDegree--;
    }

    List<Integer> getNeighbors(){
        return this.neighbors;
    }

    Boolean hasEnteringEdages(){
        return this.inDegree > 0;
    }

    void addNeighbor(Integer neighbor){
        this.neighbors.add(neighbor);
    }
}
